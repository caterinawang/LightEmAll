// an Edge representing the connection between the first node to the second
class Edge {
  GamePiece fromNode;
  GamePiece toNode;
  int weight;

  // a constructor that takes in all necessary values
  Edge(GamePiece fromNode, GamePiece toNode, int weight) {
    this.fromNode = fromNode;
    this.toNode = toNode;
    this.weight = weight;
  }

  // a constructor that takes in the two nodes and sets the weight to 1
  Edge(GamePiece fromNode, GamePiece toNode) {
    this(fromNode, toNode, 1);
  }
}
