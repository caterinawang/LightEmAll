import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;

import javalib.worldimages.*;

// a class for utility functions
class Utils {

  Color yellow = Color.YELLOW;
  Color gold = new Color(255, 215, 0);
  Color orange = new Color(255, 165, 0);
  Color darkOrange = new Color(255, 140, 0);
  Color red = Color.RED;
  Color maroon = new Color(128, 0, 0);

  ArrayList<Color> colorList = new ArrayList<Color>(
      Arrays.asList(yellow, yellow, yellow, yellow, gold, gold, gold, gold, orange, orange, orange,
          darkOrange, darkOrange, darkOrange, red, red, maroon));

  // ------------------------------------------------------------------------------------

  int wireLength = 35;
  WorldImage horizWire = new RectangleImage(wireLength, 5, OutlineMode.SOLID, Color.LIGHT_GRAY);
  WorldImage horizNoWire = new RectangleImage(wireLength, 5, OutlineMode.SOLID, Color.DARK_GRAY);
  WorldImage vertiWire = new RectangleImage(5, wireLength, OutlineMode.SOLID, Color.LIGHT_GRAY);
  WorldImage vertiNoWire = new RectangleImage(5, wireLength, OutlineMode.SOLID, Color.DARK_GRAY);

  WorldImage horizWireLit = new RectangleImage(wireLength, 5, OutlineMode.SOLID, Color.YELLOW);
  WorldImage vertiWireLit = new RectangleImage(5, wireLength, OutlineMode.SOLID, Color.YELLOW);

  // draw a wire given whether or not it exists and its direction
  public WorldImage drawWire(boolean hasWire, String direction) {
    if (hasWire) {
      return new Utils().drawExistingWire(direction);
    }
    else {
      return new Utils().drawNoWire(direction);
    }
  }

  // draw a wire with the given direction, assuming it exists
  public WorldImage drawExistingWire(String direction) {
    if (direction.equals("left")) {
      return horizWire.movePinhole(17.5, 0);
    }
    else if (direction.equals("right")) {
      return horizWire.movePinhole(-17.5, 0);
    }
    else if (direction.equals("top")) {
      return vertiWire.movePinhole(0, 17.5);
    }
    else {
      return vertiWire.movePinhole(0, -17.5);
    }
  }

  // draw a wire with the given direction, assuming it exists
  public WorldImage drawNoWire(String direction) {
    if (direction.equals("left")) {
      return horizNoWire.movePinhole(17.5, 0);
    }
    else if (direction.equals("right")) {
      return horizNoWire.movePinhole(-17.5, 0);
    }
    else if (direction.equals("top")) {
      return vertiNoWire.movePinhole(0, 17.5);
    }
    else {
      return vertiNoWire.movePinhole(0, -17.5);
    }
  }

  // draw a wire given whether or not it exists and its direction
  public WorldImage drawWireLit(boolean hasWire, String direction, int distance) {
    if (hasWire) {
      return new Utils().drawExistingWireLit(direction, distance);
    }
    else {
      return new Utils().drawNoWire(direction);
    }
  }

  // draw a wire with the given direction, assuming it exists
  public WorldImage drawExistingWireLit(String direction, int distance) {
    WorldImage horizWireLit = new RectangleImage(wireLength, 5, OutlineMode.SOLID,
        colorList.get(distance));
    WorldImage vertiWireLit = new RectangleImage(5, wireLength, OutlineMode.SOLID,
        colorList.get(distance));

    if (direction.equals("left")) {
      return horizWireLit.movePinhole(17.5, 0);
    }
    else if (direction.equals("right")) {
      return horizWireLit.movePinhole(-17.5, 0);
    }
    else if (direction.equals("top")) {
      return vertiWireLit.movePinhole(0, 17.5);
    }
    else {
      return vertiWireLit.movePinhole(0, -17.5);
    }
  }

  // ------------------------------------------------------------------------------------

  // generate an empty board with the specified width and height
  public ArrayList<Column> generateEmptyBoard(int width, int height) {
    ArrayList<Column> board = new ArrayList<Column>();
    int boardWidth = 0;

    while (boardWidth < width) {
      board.add(new Utils().generateEmptyCol(boardWidth, height));
      boardWidth += 1;
    }
    return board;
  }

  // generate an empty column
  public Column generateEmptyCol(int width, int height) {
    ArrayList<GamePiece> list = new ArrayList<GamePiece>();
    int newHeight = 0;

    while (newHeight < height) {
      list.add(new GamePiece(width, newHeight));
      newHeight += 1;
    }
    return new Column(list);
  }

  // ------------------------------------------------------------------------------------

  // sort the given list of edges based on the given edge comparator
  public ArrayList<Edge> sortEdges(ArrayList<Edge> allEdges, IComp<Edge> edgeComp) {
    ArrayList<Edge> oldList = allEdges;
    ArrayList<Edge> newList = new ArrayList<Edge>();

    for (Edge e : oldList) {
      newList = new Utils().placeEdge(newList, e, edgeComp);
    }
    return newList;
  }

  // place the given edge into the given list based on the given comparator
  public ArrayList<Edge> placeEdge(ArrayList<Edge> edgeList, Edge e, IComp<Edge> edgeComp) {
    ArrayList<Edge> newList = edgeList;

    for (int i = 0; i < newList.size(); i++) {
      if (new EdgeComp().apply(e, newList.get(i))) {
        newList.add(i, e);
        return newList;
      }
    }
    newList.add(e);
    return newList;
  }

  // ------------------------------------------------------------------------------------
  
}
