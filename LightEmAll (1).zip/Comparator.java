// determine if the first T should come before the second
interface IComp<T> {

  // should the first T come before the second in a list?
  boolean apply(T t1, T t2);
}

// should the first edge come before the second when sorted by edge weights?
class EdgeComp implements IComp<Edge> {

  // should the first edge come before the second if sorted by edge weights?
  public boolean apply(Edge e1, Edge e2) {
    return (e1.weight - e2.weight) < 0;
  }
}
