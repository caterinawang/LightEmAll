import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Random;

import javalib.impworld.World;
import javalib.impworld.WorldScene;
import javalib.worldimages.*;

class LightEmAll extends World {
  // a list of columns of GamePieces,
  // i.e., represents the board in column-major order
  ArrayList<Column> board;
  // a list of all nodes
  ArrayList<GamePiece> nodes;
  // a list of edges of the minimum spanning tree
  ArrayList<Edge> mst;
  // the width and height of the board
  int width;
  int height;
  // the current location of the power station,
  // as well as its effective radius
  int powerRow;
  int powerCol;
  int radius;
  int timePassed;
  int totalMoves;
  int bestScore;
  Random rand;

  LightEmAll(ArrayList<Column> board, ArrayList<GamePiece> nodes, ArrayList<Edge> mst, int width,
      int height, int powerRow, int powerCol, int radius, Random rand) {
    this.board = board;
    this.nodes = nodes;
    this.mst = mst;
    this.width = width;
    this.height = height;
    this.powerRow = powerRow;
    this.powerCol = powerCol;
    this.radius = radius;
    this.timePassed = 0;
    this.totalMoves = 0;
    this.bestScore = 0;
    this.rand = rand;

    // update each piece to contain its neighboring pieces
    this.updateNeighbors();
    // update this to contain all GamePieces as nodes
    this.updateNodes();
    // create a minimum spanning tree by randomizing the board layout
    this.updateMST();
    // set the distances of each piece from the power station
    this.updateDistances();
    // update the radius of this board based on the minimum spanning tree
    this.updateRadius();
    // rotate each piece a random amount of times
    this.randomRotation();
    // update each GamePiece to have its connected pieces
    this.updateConnected();
    // update the status of each piece to be lit or unlit based on the board radius
    this.updateLit();

  }

  // a constructor that makes a new random board with the given width and height
  LightEmAll(int width, int height) {
    this(new Utils().generateEmptyBoard(width, height), new ArrayList<GamePiece>(),
        new ArrayList<Edge>(), width, height, 0, 0, 0, new Random());

    GamePiece powerPiece = this.board.get(powerCol).pieces.get(powerRow);
    powerPiece.powerStation = true;
  }
  
  // a constructor that makes a new random board with the given width and height
  LightEmAll(int width, int height, Random rand) {
    this(new Utils().generateEmptyBoard(width, height), new ArrayList<GamePiece>(),
        new ArrayList<Edge>(), width, height, 0, 0, 0, rand);

    GamePiece powerPiece = this.board.get(powerCol).pieces.get(powerRow);
    powerPiece.powerStation = true;
  }

  // ------------------------------------------------------------------------------------

  // makeScene method for the world
  public WorldScene makeScene() {
    WorldImage gameImage = this.mainDraw();
    int gameWidth = (int) gameImage.getWidth();
    int gameHeight = (int) gameImage.getHeight();
    WorldScene background = new WorldScene(gameWidth, gameHeight);

    background.placeImageXY(gameImage, gameWidth / 2, gameHeight / 2);
    return background;
  }

  // draw the entire board
  WorldImage mainDraw() {
    return new OverlayOffsetImage(this.drawGame(), 0, -40, this.drawHeader());
  }

  // draw this entire game
  WorldImage drawGame() {
    WorldImage board = new EmptyImage();
    Column powerCol = this.board.get(this.powerCol);
    GamePiece powerPiece = powerCol.pieces.get(this.powerRow);

    for (Column col : this.board) {
      board = new BesideImage(board, col.drawColumn(powerPiece, this.radius));
    }

    return board;
  }

  // draw the timer of this game
  public WorldImage drawTimer() {
    Color gold = new Color(255, 215, 0);
    WorldImage bg = new RectangleImage(120, 50, OutlineMode.SOLID, Color.WHITE);
    WorldImage frame = new RectangleImage(120, 50, OutlineMode.OUTLINE, gold);
    Integer time = this.timePassed / 28;
    WorldImage timeText = new TextImage(time.toString(), 16, Color.BLACK);
    WorldImage headText = new TextImage("Time Elapsed:", 16, Color.BLACK);
    WorldImage timer = new OverlayImage(new AboveImage(headText, timeText),
        new OverlayImage(frame, bg));

    return timer;
  }

  // draw the total moves of this game
  public WorldImage drawTotalMoves() {
    Color gold = new Color(255, 215, 0);
    WorldImage bg = new RectangleImage(120, 50, OutlineMode.SOLID, Color.WHITE);
    WorldImage frame = new RectangleImage(120, 50, OutlineMode.OUTLINE, gold);
    Integer moves = this.totalMoves;
    Integer best = this.bestScore;
    WorldImage moveText = new TextImage("Total Rotations: " + moves.toString(), 13, Color.BLACK);
    WorldImage minText = new TextImage("Min Rotations: " + best.toString(), 13, Color.BLACK);
    WorldImage counter = new OverlayImage(new AboveImage(moveText, minText),
        new OverlayImage(frame, bg));

    return counter;
  }

  // draw the start over button
  public WorldImage drawStartOver() {
    Color gold = new Color(255, 215, 0);
    WorldImage bg = new RectangleImage(150, 30, OutlineMode.SOLID, Color.WHITE);
    WorldImage frame = new RectangleImage(150, 30, OutlineMode.OUTLINE, gold);
    WorldImage text = new TextImage("Start Over", 20, Color.BLACK);
    WorldImage startOver = new OverlayImage(text, new OverlayImage(frame, bg));

    return startOver;
  }

  // determine which background to display based on the width of the game
  public WorldImage determineBackground() {
    Color bgColor = new Color(150, 220, 210);

    if (this.width <= 6) {
      return new RectangleImage(520, (int) this.drawGame().getHeight() + 115, OutlineMode.SOLID,
          bgColor);
    }
    else {
      return new RectangleImage((int) this.drawGame().getWidth() + 30,
          (int) this.drawGame().getHeight() + 115, OutlineMode.SOLID, bgColor);
    }
  }

  // draw the header of this game
  public WorldImage drawHeader() {
    Color gold = new Color(255, 215, 0);
    WorldImage bg = this.determineBackground();

    double titleY = (bg.getHeight() / 2 - 30);
    WorldImage title = new TextImage("LightEmAll!", 30, gold);
    WorldImage withTitle = new OverlayOffsetImage(title, 0, titleY, bg);

    double timerX = (bg.getWidth() / 2 - 80) * -1;
    double timerY = (bg.getHeight() / 2) - 50;
    WorldImage withTimer = new OverlayOffsetImage(this.drawTimer(), timerX, timerY, withTitle);

    double movesX = (bg.getWidth() / 2 - 80);
    double movesY = (bg.getHeight() / 2) - 50;
    WorldImage withMoves = new OverlayOffsetImage(this.drawTotalMoves(), movesX, movesY, withTimer);

    double startY = (bg.getHeight() / 2 - 70);
    WorldImage withStart = new OverlayOffsetImage(this.drawStartOver(), 0, startY, withMoves);

    return withStart;
  }

  // ------------------------------------------------------------------------------------

  // EFFECT: rotate the piece that was clicked on
  public void onMouseClicked(Posn p) {
    Column clickedCol = this.board.get(this.colClicked(p.x));
    GamePiece clickedPiece = clickedCol.pieces.get(clickedCol.determinePiece(p.y));

    if (this.clickedBoard(p)) {
      this.totalMoves += 1;
      clickedPiece.rotate();

      this.updateNeighbors();
      this.updateConnected();
      this.updateDistances();
      this.updateLit();
    }
    else if (this.clickedStartOver(p)) {
      this.startOver();
    }
  }

  // did the user click somewhere in the game board?
  public boolean clickedBoard(Posn p) {
    if (this.width <= 6) {
      int startingX = (520 / 2) - (this.width * 70 / 2);
      return (p.x >= startingX) && (p.x <= (this.width * 70) + startingX) && (p.y >= 100)
          && (p.y <= this.height * 70 + 100);
    }
    else {
      return (p.x >= 30) && (p.x <= this.width * 70 + 30) && (p.y >= 100)
          && (p.y <= this.height * 70 + 100);
    }
  }

  // determine the index of the column at the given x-coordinate
  public int colClicked(int x) {
    int colIndex = 0;

    if (this.width <= 6) {
      for (int i = 0; i < this.board.size(); i++) {
        int startingX = (520 / 2) - (this.width * 70 / 2);
        if (i * 70 + startingX <= x) {
          colIndex = i;
        }
      }
      return colIndex;
    }

    else {
      for (int i = 0; i < this.board.size(); i++) {
        if (i * 70 <= x) {
          colIndex = i;
        }
      }
      return colIndex;
    }
  }

  // did the user click in the coordinates of the start over button?
  public boolean clickedStartOver(Posn p) {
    int xStart = (int) (this.mainDraw().getWidth() / 2) - 75;
    int xEnd = (int) (this.mainDraw().getWidth() / 2) + 75;
    int yStart = 50;
    int yEnd = 80;

    return (p.x >= xStart) && (p.x <= xEnd) && (p.y >= yStart) && (p.y <= yEnd);
  }

  // EFFECT: generate a new random board when the start over button has been
  // clicked
  public void startOver() {
    this.board.get(this.powerCol).pieces.get(this.powerRow).powerStation = false;
    this.board = new Utils().generateEmptyBoard(this.width, this.height);
    this.nodes.clear();
    this.mst.clear();
    this.powerRow = 0;
    this.powerCol = 0;
    this.board.get(0).pieces.get(0).powerStation = true;
    this.bestScore = 0;

    // update each piece to contain its neighboring pieces
    this.updateNeighbors();
    // update this to contain all GamePieces as nodes
    this.updateNodes();
    // create a minimum spanning tree by randomizing the board layout
    this.updateMST();
    // set the distances of each piece from the power station
    this.updateDistances();
    // update the radius of this board based on the minimum spanning tree
    this.updateRadius();
    // rotate each piece a random amount of times
    this.randomRotation();
    // update each GamePiece to have its connected pieces
    this.updateConnected();
    // update the status of each piece to be lit or unlit based on the board radius
    this.updateLit();
    this.totalMoves = 0;
    this.timePassed = 0;
    this.rand = new Random(this.rand.nextInt(5));
  }

  // ------------------------------------------------------------------------------------

  // EFFECT: handle the keys pressed on the keyboard that move the powerStation
  public void onKeyEvent(String k) {
    Column pCol = this.board.get(this.powerCol);
    GamePiece pPiece = pCol.pieces.get(this.powerRow);

    if (k.equals("right")) {
      this.moveRight(pPiece);
    }
    else if (k.equals("left")) {
      this.moveLeft(pPiece);
    }
    else if (k.equals("up")) {
      this.moveUp(pPiece);
    }
    else if (k.equals("down")) {
      this.moveDown(pPiece);
    }

    this.updateNeighbors();
    this.updateConnected();
    this.updateDistances();
    this.updateLit();
  }

  // EFFECT: move the power station one piece to the left
  public void moveLeft(GamePiece currPiece) {

    if (currPiece.col > 0) {
      Column nextCol = this.board.get(currPiece.col - 1);
      GamePiece nextPiece = nextCol.pieces.get(currPiece.row);

      if (currPiece.areConnected(nextPiece)) {
        currPiece.powerStation = false;
        nextPiece.powerStation = true;
        this.powerRow = nextPiece.row;
        this.powerCol = nextPiece.col;
      }
    }
  }

  // EFFECT: move the power station one piece to the right
  public void moveRight(GamePiece currPiece) {
    if (currPiece.col + 1 < this.board.size()) {
      Column nextCol = this.board.get(currPiece.col + 1);
      GamePiece nextPiece = nextCol.pieces.get(currPiece.row);

      if (currPiece.areConnected(nextPiece)) {
        currPiece.powerStation = false;
        nextPiece.powerStation = true;
        this.powerRow = nextPiece.row;
        this.powerCol = nextPiece.col;
      }
    }
  }

  // EFFECT: move the power station one piece up
  public void moveUp(GamePiece currPiece) {
    if (currPiece.row > 0) {
      Column nextCol = this.board.get(currPiece.col);
      GamePiece nextPiece = nextCol.pieces.get(currPiece.row - 1);

      if (currPiece.areConnected(nextPiece)) {
        currPiece.powerStation = false;
        nextPiece.powerStation = true;
        this.powerRow = nextPiece.row;
        this.powerCol = nextPiece.col;
      }
    }
  }

  // EFFECT: move the power station one piece down
  public void moveDown(GamePiece currPiece) {
    if (currPiece.row + 1 < this.board.get(0).pieces.size()) {
      Column nextCol = this.board.get(currPiece.col);
      GamePiece nextPiece = nextCol.pieces.get(currPiece.row + 1);

      if (currPiece.areConnected(nextPiece)) {
        currPiece.powerStation = false;
        nextPiece.powerStation = true;
        this.powerRow = nextPiece.row;
        this.powerCol = nextPiece.col;
      }
    }
  }

  // ------------------------------------------------------------------------------------

  // EFFECT: increment the timer when the game ticks
  public void onTick() {
    this.timePassed += 1;
  }
  // ------------------------------------------------------------------------------------

  // EFFECT: update the neighbors of each cell in this game to contain the
  // surrounding
  // cells
  public void updateNeighbors() {
    this.clearAllNeighbors();

    for (int i = 0; i < this.board.size(); i++) {

      if (i == 0) {
        this.board.get(0).updateNeighborsEdge(this.board.get(1));
      }
      else {
        this.updateNeighborsHelp(i);
      }
    }
  }

  // EFFECT: update the neighbors of each cell in this game to contain the
  // surrounding
  // cells, ignoring the first row
  public void updateNeighborsHelp(int i) {
    if (i + 1 == this.board.size()) {
      this.board.get(i).updateNeighborsEdge(this.board.get(i - 1));
    }
    else {
      this.board.get(i).updateNeighborsMiddle(this.board.get(i - 1), this.board.get(i + 1));
    }
  }

  // EFFECT: clear the neighbor list of every piece in this board
  public void clearAllNeighbors() {
    for (Column c : this.board) {
      for (GamePiece gp : c.pieces) {
        gp.neighbors.clear();
      }
    }
  }

  // EFFECT: set all pieces in this board to be powered or unpowered based on
  // their distance and connection to thr power station
  public void updateLit() {
    Column powerCol = this.board.get(this.powerCol);
    GamePiece powerPiece = powerCol.pieces.get(this.powerRow);
    this.setAllUnlit();

    powerPiece.updateLit(this.radius, new ArrayList<GamePiece>());
  }

  // EFFECT: Set all GamePieces in the board to be unlit
  public void setAllUnlit() {
    for (Column c : this.board) {
      for (GamePiece gp : c.pieces) {
        gp.isLit = false;
      }
    }
  }

  // EFFECT: update the distances of each piece in this board from the power
  // station
  public void updateDistances() {
    Column powerCol = this.board.get(this.powerCol);
    GamePiece powerPiece = powerCol.pieces.get(this.powerRow);

    powerPiece.updateDistances(this.radius, 0, new ArrayList<GamePiece>());
    this.setAllDistances();
  }

  // EFFECT: set the distances of each piece from the power station
  public void setAllDistances() {
    for (Column c : this.board) {
      for (GamePiece gp : c.pieces) {
        gp.setDistances();
      }
    }
  }

  // EFFECT: add every GamePiece in this board to the list of nodes
  public void updateNodes() {
    for (Column c : this.board) {
      for (GamePiece gp : c.pieces) {
        this.nodes.add(gp);
      }
    }
  }

  // EFFECT: update the connections of each piece in this board
  public void updateConnected() {
    for (Column c : this.board) {
      for (GamePiece gp : c.pieces) {
        gp.updateConnected();
      }
    }
  }

  // EFFECT: Update each piece in this board to contain the necessary edges
  public void updateEdges() {
    for (Column c : this.board) {
      for (GamePiece gp : c.pieces) {
        gp.updateEdges();
      }
    }
  }

  // EFFECT: rotate each GamePiece in this board a random amount of times
  public void randomRotation() {
    for (Column c : this.board) {
      for (GamePiece gp : c.pieces) {
        int times = this.rand.nextInt(4);
        boolean oldL = gp.left;
        boolean oldR = gp.right;
        boolean oldT = gp.top;
        boolean oldB = gp.bottom;

        gp.rotateAmount(times);
        int rotationsNeeded = gp.countRotationsNeeded(oldL, oldR, oldT, oldB, 0);
        this.bestScore += rotationsNeeded;
        gp.unrotateAmount(rotationsNeeded);
      }
    }
  }

  // ------------------------------------------------------------------------------------

  // EFFECT: update the radius of this board based on the length of the minimum
  // spanning tree
  public void updateRadius() {
    GamePiece finalPiece = this.lastFound(this.board.get(0).pieces.get(0));
    GamePiece firstPiece = this.lastFound(finalPiece);

    this.radius = firstPiece.findDistance(finalPiece) / 2 + 1;
  }

  // return the last found GamePiece in this board when starting from the given
  // piece
  public GamePiece lastFound(GamePiece starting) {
    ArrayList<GamePiece> visited = new ArrayList<GamePiece>();
    Deque<GamePiece> worklist = new ArrayDeque<GamePiece>();

    GamePiece lastVisited = starting;
    worklist.add(starting);

    while (!visited.containsAll(this.nodes)) {
      GamePiece next = worklist.removeFirst();

      if (visited.contains(next)) {
        lastVisited = next;
      }
      else {

        for (GamePiece gp : next.connected) {
          worklist.add(gp);
        }
        visited.add(next);
        lastVisited = next;
      }
    }
    return lastVisited;
  }

  // ------------------------------------------------------------------------------------

  // EFFECT: Update the minimum spanning tree of this game based on random edges
  // created
  public void updateMST() {
    ArrayList<Edge> allPossible = this.allSortedEdges();

    for (Edge e : allPossible) {
      if (!this.createsCycle(e)) {
        this.mst.add(e);
        e.fromNode.addEdgeWireConnection(e);
      }
    }
  }

  // return a list of every possible edge in this board sorted by increasing edge
  // weights
  public ArrayList<Edge> allSortedEdges() {
    ArrayList<Edge> oldList = this.allPossibleEdges();

    return new Utils().sortEdges(oldList, new EdgeComp());
  }

  // create a list of every possible edge in this board
  public ArrayList<Edge> allPossibleEdges() {
    ArrayList<Edge> edgeList = new ArrayList<Edge>();

    for (Column c : this.board) {
      for (GamePiece gp : c.pieces) {
        edgeList.addAll(gp.allPossibleEdges(this.rand));
      }
    }
    return edgeList;
  }

  // would the addition of the given Edge into this board create a cycle?
  public boolean createsCycle(Edge e) {
    GamePiece from = e.fromNode;

    int beforeConnections = from.countConnected();
    int afterConnections = from.countAfterConnections(e);
    e.fromNode.connected.remove(e.toNode);

    return beforeConnections == afterConnections;
  }

  // ------------------------------------------------------------------------------------

  // end the game when all pieces have been lit up
  public WorldEnd worldEnds() {
    return new WorldEnd(this.areAllLit(), this.drawEnding());
  }

  // is every GamePiece in this board lit up?
  public boolean areAllLit() {
    for (Column c : this.board) {
      for (GamePiece gp : c.pieces) {
        if (!gp.isLit) {
          return false;
        }
      }
    }
    return true;
  }

  // draw the ending of this game
  public WorldScene drawEnding() {
    Integer score = this.totalMoves - this.bestScore;
    Color bgColor = new Color(150, 220, 210);
    WorldImage bg = new RectangleImage(320, 150, OutlineMode.SOLID, bgColor);
    WorldImage frame = new RectangleImage(330, 160, OutlineMode.SOLID, Color.BLACK);
    WorldImage backing = new OverlayImage(bg, frame);

    WorldImage endingText = new TextImage("You Won!", 40, Color.WHITE);
    WorldImage spacer = new RectangleImage(50, 10, OutlineMode.SOLID, bgColor);
    WorldImage scoreText = new TextImage("Your Score: " + score.toString(), 30, Color.BLUE);
    WorldImage descripText = new TextImage("(the lower the better)", 20, Color.BLUE);
    WorldImage allText = new AboveImage(endingText,
        new AboveImage(spacer, new AboveImage(scoreText, descripText)));

    WorldImage ending = new OverlayImage(allText, backing);
    WorldScene gameScene = this.makeScene();

    gameScene.placeImageXY(ending, (int) this.mainDraw().getWidth() / 2,
        (int) this.mainDraw().getHeight() / 2);
    return gameScene;
  }

  // ------------------------------------------------------------------------------------

}
