import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import javalib.worldimages.*;
import tester.*;

// examples data and tests
class ExamplesLEA {
  GamePiece gp1;
  GamePiece gp2;
  GamePiece gp3;
  GamePiece gp4;
  GamePiece gp5;
  GamePiece gp6;
  GamePiece gp7;
  GamePiece gp8;
  GamePiece gp9;
  GamePiece gp10;
  GamePiece gp11;
  GamePiece gp12;
  GamePiece gp13;
  GamePiece gp14;
  GamePiece gp15;
  GamePiece gp16;
  GamePiece gp17;
  GamePiece gp18;
  GamePiece gp19;
  GamePiece gp20;
  GamePiece gp21;
  GamePiece gp22;
  GamePiece gp23;
  GamePiece gp24;
  GamePiece gp25;

  Column col1;
  Column col2;
  Column col3;
  Column col4;
  Column col5;
  Column miniCol;
  ArrayList<Column> board1Columns;
  ArrayList<GamePiece> board1Nodes;
  ArrayList<Edge> board1Edges;
  ArrayList<Color> colorList;
  Color yellow;
  Color gold;
  Color orange;
  Color darkOrange;
  Color red;
  Color maroon;

  Edge edge1;
  Edge edge2;
  Edge edge3;

  IComp<Edge> edgeComp;

  LightEmAll LEA1;
  LightEmAll LEAseed4x4;
  LightEmAll LEArand4x4;
  LightEmAll LEAseed8x8;
  LightEmAll LEArand8x8;

  // the initial data to be tested
  void initData() {
    // all the gamePieces on our manual board
    this.gp1 = new GamePiece(0, 0, false, true, false, false, false);
    this.gp2 = new GamePiece(0, 1, true, true, false, false, false);
    this.gp3 = new GamePiece(0, 2, true, true, false, true, false);
    this.gp4 = new GamePiece(0, 3, true, true, false, false, false);
    this.gp5 = new GamePiece(0, 4, true, false, false, false, false);
    this.gp6 = new GamePiece(1, 0, false, true, false, false, false);
    this.gp7 = new GamePiece(1, 1, true, true, false, false, false);
    this.gp8 = new GamePiece(1, 2, true, true, true, true, false);
    this.gp9 = new GamePiece(1, 3, true, true, false, false, false);
    this.gp10 = new GamePiece(1, 4, true, false, false, false, false);
    this.gp11 = new GamePiece(2, 0, false, true, false, false, false);
    this.gp12 = new GamePiece(2, 1, true, true, false, false, false);
    this.gp13 = new GamePiece(2, 2, true, true, true, true, true);
    this.gp14 = new GamePiece(2, 3, true, true, false, false, false);
    this.gp15 = new GamePiece(2, 4, true, false, false, false, false);
    this.gp16 = new GamePiece(3, 0, false, true, false, false, false);
    this.gp17 = new GamePiece(3, 1, true, true, false, false, false);
    this.gp18 = new GamePiece(3, 2, true, true, true, true, false);
    this.gp19 = new GamePiece(3, 3, true, true, false, false, false);
    this.gp20 = new GamePiece(3, 4, true, false, false, false, false);
    this.gp21 = new GamePiece(4, 0, false, true, false, false, false);
    this.gp22 = new GamePiece(4, 1, true, true, false, false, false);
    this.gp23 = new GamePiece(4, 2, true, true, true, false, false);
    this.gp24 = new GamePiece(4, 3, true, true, false, false, false);
    this.gp25 = new GamePiece(4, 4, true, false, false, false, false);

    this.col1 = new Column(new ArrayList<GamePiece>(
        Arrays.asList(this.gp1, this.gp6, this.gp11, this.gp16, this.gp21)));
    this.col2 = new Column(new ArrayList<GamePiece>(
        Arrays.asList(this.gp2, this.gp7, this.gp12, this.gp17, this.gp22)));
    this.col3 = new Column(new ArrayList<GamePiece>(
        Arrays.asList(this.gp3, this.gp8, this.gp13, this.gp18, this.gp23)));
    this.col4 = new Column(new ArrayList<GamePiece>(
        Arrays.asList(this.gp4, this.gp9, this.gp14, this.gp19, this.gp24)));
    this.col5 = new Column(new ArrayList<GamePiece>(
        Arrays.asList(this.gp5, this.gp10, this.gp15, this.gp20, this.gp25)));
    this.miniCol = new Column(new ArrayList<GamePiece>(Arrays.asList(this.gp1, this.gp2)));

    this.edge1 = new Edge(gp1, gp2, 5);
    this.edge2 = new Edge(gp2, gp3, 2);
    this.edge3 = new Edge(gp3, gp4, 7);

    this.edgeComp = new EdgeComp();
    this.colorList = new ArrayList<Color>(
        Arrays.asList(yellow, yellow, yellow, yellow, gold, gold, gold, gold, orange, orange,
            orange, darkOrange, darkOrange, darkOrange, red, red, maroon));
    this.yellow = Color.YELLOW;
    this.gold = new Color(255, 215, 0);
    this.orange = new Color(255, 165, 0);
    this.darkOrange = new Color(255, 140, 0);
    this.red = Color.RED;
    this.maroon = new Color(128, 0, 0);

    this.board1Columns = new ArrayList<Column>(
        Arrays.asList(this.col1, this.col2, this.col3, this.col4, this.col5));
    this.LEA1 = new LightEmAll(this.board1Columns, new ArrayList<GamePiece>(),
        new ArrayList<Edge>(), 5, 5, 2, 2, 2, new Random());
    
    LEAseed4x4 = new LightEmAll(4, 4, new Random(0));
    LEArand4x4 = new LightEmAll(4, 4);
    LEAseed8x8 = new LightEmAll(8, 8, new Random(0));
    LEArand8x8 = new LightEmAll(8, 8);
  }

  // test the method updateNeighbors()
  public boolean testUpdateNeighbors(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece topLeft = game.board.get(0).pieces.get(0);
    GamePiece botRight = game.board.get(7).pieces.get(7);
    GamePiece midLeft = game.board.get(0).pieces.get(3);
    GamePiece midMid = game.board.get(3).pieces.get(3);

    return t.checkExpect(topLeft.neighbors.size(), 2) 
        && t.checkExpect(botRight.neighbors.size(), 2)
        && t.checkExpect(midLeft.neighbors.size(), 3) 
        && t.checkExpect(midMid.neighbors.size(), 4);
  }
  
  // test the method updateNeighborsEdge()
  public boolean testUpdateNeighborsEdge(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece topLeft = game.board.get(0).pieces.get(0);
    GamePiece botRight = game.board.get(7).pieces.get(7);
    GamePiece midLeft = game.board.get(0).pieces.get(3);

    return t.checkExpect(topLeft.neighbors.size(), 2) 
        && t.checkExpect(botRight.neighbors.size(), 2)
        && t.checkExpect(midLeft.neighbors.size(), 3);
  }
  
  // test the method updateNeighborsMiddle()
  public boolean testUpdateNeighborsMiddle(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midTop = game.board.get(2).pieces.get(0);
    
    return t.checkExpect(midMid.neighbors.size(), 4)
        && t.checkExpect(midTop.neighbors.size(), 3);
  }

  // test the method rotate()
  public void testRotate(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);

    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, false);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);

    midMid.rotate();
    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, true);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, false);
  }

  // test the method rotate()
  public void testUnrotate(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);

    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, false);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);

    midMid.unrotate();
    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, true);
    t.checkExpect(midMid.top, false);
    t.checkExpect(midMid.bottom, true);
  }

  // test the method rotate()
  public void testRotateAmount(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);

    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, false);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);

    midMid.rotateAmount(0);
    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, false);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);

    midMid.rotateAmount(2);
    t.checkExpect(midMid.left, false);
    t.checkExpect(midMid.right, true);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);
  }

  // test the method rotate()
  public void testUnrotateAmount(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);

    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, false);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);

    midMid.unrotateAmount(0);
    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, false);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);

    midMid.unrotateAmount(2);
    t.checkExpect(midMid.left, false);
    t.checkExpect(midMid.right, true);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);
  }

  // test the method areConnected(GamePiece other)
  public boolean testAreConnected(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midAbove = game.board.get(3).pieces.get(2);
    GamePiece midBelow = game.board.get(3).pieces.get(4);
    GamePiece midLeft = game.board.get(2).pieces.get(3);
    GamePiece midRight = game.board.get(4).pieces.get(3);

    return t.checkExpect(midMid.areConnected(midAbove), true)
        && t.checkExpect(midMid.areConnected(midBelow), true)
        && t.checkExpect(midAbove.areConnected(midMid), true)
        && t.checkExpect(midMid.areConnected(midLeft), false)
        && t.checkExpect(midMid.areConnected(midRight), false)
        && t.checkExpect(midRight.areConnected(midMid), false);
  }

  // test the method areConnectedRow(GamePiece other)
  public boolean testAreConnectedRow(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(6).pieces.get(5);
    GamePiece midLeft = game.board.get(5).pieces.get(5);
    GamePiece midRight = game.board.get(7).pieces.get(5);
    GamePiece midEdge = game.board.get(0).pieces.get(5);

    return t.checkExpect(midMid.areConnectedRow(midLeft), true)
        && t.checkExpect(midLeft.areConnectedRow(midMid), true)
        && t.checkExpect(midMid.areConnectedRow(midRight), false)
        && t.checkExpect(midRight.areConnectedRow(midMid), false)
        && t.checkExpect(midMid.areConnectedRow(midEdge), false)
        && t.checkExpect(midEdge.areConnectedRow(midMid), false);
  }

  // test the method areConnectedCol(GamePiece other)
  public boolean testAreConnectedCol(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midAbove = game.board.get(3).pieces.get(2);
    GamePiece midBelow = game.board.get(3).pieces.get(4);
    GamePiece midTop = game.board.get(3).pieces.get(0);

    return t.checkExpect(midMid.areConnectedCol(midAbove), true)
        && t.checkExpect(midMid.areConnectedCol(midBelow), true)
        && t.checkExpect(midAbove.areConnectedCol(midMid), true)
        && t.checkExpect(midMid.areConnectedCol(midTop), false)
        && t.checkExpect(midTop.areConnectedCol(midMid), false);
  }

  // test the method updateConnected()
  public boolean testUpdateConnected(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midAbove = game.board.get(3).pieces.get(2);
    GamePiece midBelow = game.board.get(3).pieces.get(4);
    GamePiece midTop = game.board.get(3).pieces.get(0);

    return t.checkExpect(midMid.connected.size(), 2) 
        && t.checkExpect(midAbove.connected.size(), 1)
        && t.checkExpect(midBelow.connected.size(), 2) 
        && t.checkExpect(midTop.connected.size(), 1);
  }

  // test the method updateEdges()
  public boolean testUpdateEdges(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midAbove = game.board.get(3).pieces.get(2);
    GamePiece midBelow = game.board.get(3).pieces.get(4);
    GamePiece midTop = game.board.get(3).pieces.get(0);

    return t.checkExpect(midMid.outEdges.size(), 3) 
        && t.checkExpect(midAbove.outEdges.size(), 3)
        && t.checkExpect(midBelow.outEdges.size(), 2) 
        && t.checkExpect(midTop.outEdges.size(), 3);
  }

  // test the method updateLit()
  public void testUpdateLit(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midAbove = game.board.get(3).pieces.get(2);
    GamePiece midBelow = game.board.get(3).pieces.get(4);
    GamePiece midTop = game.board.get(3).pieces.get(0);

    t.checkExpect(midMid.isLit, false);
    t.checkExpect(midAbove.isLit, false);
    t.checkExpect(midBelow.isLit, false);
    t.checkExpect(midTop.isLit, false);

    midMid.powerStation = true;
    midMid.updateLit(12, new ArrayList<GamePiece>());
    t.checkExpect(midMid.isLit, true);
    t.checkExpect(midAbove.isLit, true);
    t.checkExpect(midBelow.isLit, true);
    t.checkExpect(midTop.isLit, false);

  }

  // test the method updateDistances()
  public void testSetDistances(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midAbove = game.board.get(3).pieces.get(2);

    t.checkExpect(midMid.powerDistance, 0);
    t.checkExpect(midAbove.powerDistance, 0);

    midMid.powerDistance = 17;
    midAbove.powerDistance = 12;
    midMid.setDistances();
    midAbove.setDistances();
    t.checkExpect(midMid.powerDistance, 16);
    t.checkExpect(midAbove.powerDistance, 12);
  }

  // test the method updateDistances(int radius, int newRadius,
  // ArrayList<GamePiece> visited)
  public void testUpdateDistances(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midAbove = game.board.get(3).pieces.get(2);
    GamePiece midBelow = game.board.get(3).pieces.get(4);
    GamePiece midTop = game.board.get(3).pieces.get(0);

    midMid.powerStation = true;
    midMid.updateDistances(12, 0, new ArrayList<GamePiece>());
    t.checkExpect(midMid.powerDistance, 0);
    t.checkExpect(midAbove.powerDistance, 1);
    t.checkExpect(midBelow.powerDistance, 1);
    t.checkExpect(midTop.powerDistance, 0);
  }

  // test the method distance(int steps, GamePiece to, ArrayList<GamePiece>
  // visited)
  public void testDistance(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midAbove = game.board.get(3).pieces.get(2);
    GamePiece midBelow = game.board.get(3).pieces.get(4);

    midMid.distance(0, midAbove, new ArrayList<GamePiece>());
    midMid.distance(0, midBelow, new ArrayList<GamePiece>());
    t.checkExpect(midMid.stepsTaken, -1);
    t.checkExpect(midAbove.stepsTaken, 1);
    t.checkExpect(midBelow.stepsTaken, 1);
    midAbove.distance(0, midBelow, new ArrayList<GamePiece>());
    t.checkExpect(midBelow.stepsTaken, 2);

  }

  // test the method findDistance(GamePiece to)
  public boolean testFindDistance(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midAbove = game.board.get(3).pieces.get(2);
    GamePiece midBelow = game.board.get(3).pieces.get(4);

    return t.checkExpect(midMid.findDistance(midAbove), 1)
        && t.checkExpect(midMid.findDistance(midBelow), 1)
        && t.checkExpect(midAbove.findDistance(midBelow), 2)
        && t.checkExpect(midMid.findDistance(midMid), 0);
  }

  // test the method countConnected()
  public boolean testCountConnected(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midAbove = game.board.get(3).pieces.get(2);
    GamePiece midBelow = game.board.get(3).pieces.get(4);

    return t.checkExpect(midMid.countConnected(), 4) 
        && t.checkExpect(midAbove.countConnected(), 4)
        && t.checkExpect(midBelow.countConnected(), 4);
  }

  // test the method countAfterConnections(Edge e)
  public boolean testCountAfterConnections(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midLeft = game.board.get(2).pieces.get(3);
    GamePiece midRight = game.board.get(4).pieces.get(3);
    Edge leftEdge = new Edge(midMid, midLeft);
    Edge rightEdge = new Edge(midMid, midRight);

    return t.checkExpect(midMid.countAfterConnections(leftEdge), 7)
        && t.checkExpect(midMid.countAfterConnections(rightEdge), 8);
  }

  // test the method possibleEdges()
  public boolean testPossibleEdges(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midLeft = game.board.get(2).pieces.get(3);

    return t.checkExpect(midMid.allPossibleEdges(game.rand).size(), 4)
        && t.checkExpect(midLeft.allPossibleEdges(game.rand).size(), 4);
  }

  // test the method addWire(Edge e)
  public void testAddWire(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midLeft = game.board.get(2).pieces.get(3);
    GamePiece midRight = game.board.get(4).pieces.get(3);
    Edge leftEdge = new Edge(midMid, midLeft);
    Edge rightEdge = new Edge(midMid, midRight);

    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, false);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);

    midMid.addWire(leftEdge);
    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, false);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);

    midMid.addWire(rightEdge);
    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, true);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);
  }

  // test the method addEdgeWireConnection(Edge e)
  public void testAddEdgeWireConnection(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midLeft = game.board.get(2).pieces.get(3);
    GamePiece midRight = game.board.get(4).pieces.get(3);
    Edge leftEdge = new Edge(midMid, midLeft);
    Edge rightEdge = new Edge(midMid, midRight);

    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, false);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);

    midMid.addEdgeWireConnection(leftEdge);
    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, false);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);

    midMid.addEdgeWireConnection(rightEdge);
    t.checkExpect(midMid.left, true);
    t.checkExpect(midMid.right, true);
    t.checkExpect(midMid.top, true);
    t.checkExpect(midMid.bottom, true);
  }

  // test the method whichDirection(GamePiece p2)
  public boolean testWhichDirection(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    GamePiece midMid = game.board.get(3).pieces.get(3);
    GamePiece midLeft = game.board.get(2).pieces.get(3);
    GamePiece midRight = game.board.get(4).pieces.get(3);
    GamePiece midAbove = game.board.get(3).pieces.get(2);

    return t.checkExpect(midMid.whichDirection(midLeft), "left")
        && t.checkExpect(midMid.whichDirection(midRight), "right")
        && t.checkExpect(midMid.whichDirection(midAbove), "top")
        && t.checkExpect(midAbove.whichDirection(midMid), "bottom");
  }

  // test the method apply(Edge e1, Edge e2) in EdgeComp
  public boolean testEdgeComp(Tester t) {
    this.initData();
    Edge edge1 = new Edge(new GamePiece(0, 0), new GamePiece(0, 1), 5);
    Edge edge2 = new Edge(new GamePiece(0, 0), new GamePiece(0, 1), 3);

    return t.checkExpect(new EdgeComp().apply(edge1, edge2), false)
        && t.checkExpect(new EdgeComp().apply(edge2, edge1), true);
  }

  // test the method drawWire(boolean hasWire, String direction)
  public boolean testDrawWire(Tester t) {
    this.initData();
    WorldImage horizWire = new RectangleImage(35, 5, OutlineMode.SOLID, Color.LIGHT_GRAY);
    WorldImage horizNoWire = new RectangleImage(35, 5, OutlineMode.SOLID, Color.DARK_GRAY);
    WorldImage horizWire1 = horizWire.movePinhole(17.5, 0);
    WorldImage horizNoWire1 = horizNoWire.movePinhole(-17.5, 0);
    
    return t.checkExpect(new Utils().drawWire(true, "left"), horizWire1)
        && t.checkExpect(new Utils().drawWire(false, "right"), horizNoWire1);
  }
  
  // test the method onTick()
  public void testOnTick(Tester t) {
    this.initData();
    LightEmAll game = LEAseed8x8;
    
    t.checkExpect(game.timePassed, 0);
    game.onTick();
    t.checkExpect(game.timePassed, 1);
    game.onTick();
    t.checkExpect(game.timePassed, 2);
  }
  
  // tests the method drawGamePiece(GamePiece powerPiece, int powRad)
  public boolean testDrawGamePiece(Tester t) {
    this.initData();
    int cellWidth = 70;
    int cellHeight = cellWidth;
    WorldImage bg = new RectangleImage(cellWidth, cellHeight, OutlineMode.SOLID, Color.DARK_GRAY);
    WorldImage frame = new RectangleImage(cellWidth, cellHeight, OutlineMode.OUTLINE, Color.BLACK);
    WorldImage cell = new OverlayImage(frame, new OverlayImage(gp1.drawWires(gp13, 5), bg));
    WorldImage pCell = new OverlayImage(frame, new OverlayImage(gp13.drawWires(gp13, 5), bg));
    return t.checkExpect(gp1.drawGamePiece(gp13, 5), cell)
        && t.checkExpect(gp13.drawGamePiece(gp13, 5),
            new OverlayImage(new StarImage(15, 7, OutlineMode.SOLID, Color.CYAN), pCell));
  }
  
  // test the method drawGame()
  public boolean testDrawGame(Tester t) {
    this.initData();
    
    return t.checkExpect(LEA1.drawGame().getWidth(), 350.0)
        && t.checkExpect(LEA1.drawGame().getHeight(), 350.0)
        && t.checkExpect(LEAseed8x8.drawGame().getWidth(), 560.0)
        && t.checkExpect(LEAseed8x8.drawGame().getHeight(), 560.0);
  }
  
  // test the method mainDraw()
  public boolean testMainDraw(Tester t) {
    this.initData();
    
    return t.checkExpect(LEA1.mainDraw().getWidth(), 520.0)
        && t.checkExpect(LEA1.mainDraw().getHeight(), 465.0)
        && t.checkExpect(LEAseed8x8.mainDraw().getWidth(), 590.0)
        && t.checkExpect(LEAseed8x8.mainDraw().getHeight(), 675.0)
        && t.checkExpect(LEAseed4x4.mainDraw().getWidth(), 520.0)
        && t.checkExpect(LEAseed4x4.mainDraw().getHeight(), 395.0);
  }

  // run the game
  void testBigBang(Tester t) {
    this.initData();

    LightEmAll LEA = new LightEmAll(6, 6);
    int height = (int) LEA.mainDraw().getHeight();
    int width = (int) LEA.mainDraw().getWidth();
    double tickRate = 1.0 / 28.0;
    
    LEA.bigBang(width, height, tickRate);
  }
}
