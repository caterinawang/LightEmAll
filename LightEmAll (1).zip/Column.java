import java.util.ArrayList;

import javalib.worldimages.AboveImage;
import javalib.worldimages.EmptyImage;
import javalib.worldimages.WorldImage;

// a column of GamePieces
class Column {

  ArrayList<GamePiece> pieces;

  // a constructor that takes in the necessary pieces
  Column(ArrayList<GamePiece> pieces) {
    this.pieces = pieces;
  }

  // ------------------------------------------------------------------------------------

  // draw the given list of GamePieces as a column
  public WorldImage drawColumn(GamePiece powerPiece, int powRad) {
    WorldImage drawCol = new EmptyImage();

    for (GamePiece gp : this.pieces) {
      drawCol = new AboveImage(drawCol, gp.drawGamePiece(powerPiece, powRad));
    }
    return drawCol;
  }

  // ------------------------------------------------------------------------------------

  // determine which piece in the given list is at the given y- coordinate
  public int determinePiece(int y) {
    int pieceIndex = 0;

    for (int i = 0; i < this.pieces.size(); i++) {
      if (i * 70 + 100 <= y) {
        pieceIndex = i;
      }
    }
    return pieceIndex;
  }

  // ------------------------------------------------------------------------------------

  // EFFECT: update the neighbors of each piece in this column, assuming this has
  // one
  // neighboring column. The given column must be of the same size as this
  void updateNeighborsEdge(Column other) {
    for (int i = 0; i < this.pieces.size(); i++) {
      ArrayList<GamePiece> currentList = this.pieces.get(i).neighbors;

      if (i == 0) {
        currentList.add(this.pieces.get(i + 1));
        currentList.add(other.pieces.get(i));
      }
      else {
        this.updateEdgeHelp(other, i);
      }
    }
  }

  // EFFECT: update the neighbors of each piece in this column, ignoring the first
  // piece
  // The given column must be of the same size as this
  void updateEdgeHelp(Column other, int i) {
    ArrayList<GamePiece> currentList = this.pieces.get(i).neighbors;

    if (i + 1 == this.pieces.size()) {
      currentList.add(this.pieces.get(i - 1));
      currentList.add(other.pieces.get(i));
    }
    else {
      currentList.add(this.pieces.get(i + 1));
      currentList.add(this.pieces.get(i - 1));
      currentList.add(other.pieces.get(i));
    }
  }

  // EFFECT: update the neighbors of each piece in this column, assuming it has
  // two
  // neighboring column. The given column must be of the same size as this
  void updateNeighborsMiddle(Column left, Column right) {
    for (int i = 0; i < this.pieces.size(); i++) {
      ArrayList<GamePiece> currentList = this.pieces.get(i).neighbors;

      if (i == 0) {
        currentList.add(this.pieces.get(i + 1));
        currentList.add(left.pieces.get(i));
        currentList.add(right.pieces.get(i));
      }
      else {
        this.updateMiddleHelp(left, right, i);
      }
    }
  }

  // EFFECT: update the neighbors of each piece in this column, ignoring the first
  // piece
  // The given columns must be of the same size as this
  void updateMiddleHelp(Column left, Column right, int i) {
    ArrayList<GamePiece> currentList = this.pieces.get(i).neighbors;

    if (i + 1 == this.pieces.size()) {
      currentList.add(this.pieces.get(i - 1));
      currentList.add(left.pieces.get(i));
      currentList.add(right.pieces.get(i));
    }
    else {
      currentList.add(this.pieces.get(i + 1));
      currentList.add(this.pieces.get(i - 1));
      currentList.add(left.pieces.get(i));
      currentList.add(right.pieces.get(i));
    }
  }

  // ------------------------------------------------------------------------------------

}
