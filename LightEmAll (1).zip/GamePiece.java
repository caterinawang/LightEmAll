import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import javalib.worldimages.*;

class GamePiece {
  // in logical coordinates, with the origin
  // at the top-left corner of the screen
  int row;
  int col;
  // whether this GamePiece is connected to the
  // adjacent left, right, top, or bottom pieces
  boolean left;
  boolean right;
  boolean top;
  boolean bottom;
  // whether the power station is on this piece
  boolean powerStation;
  boolean isLit;
  int powerDistance;
  ArrayList<GamePiece> neighbors;
  ArrayList<GamePiece> connected;
  ArrayList<Edge> outEdges;
  int stepsTaken;

  // a constructor that takes in all necessary values
  GamePiece(int row, int col, boolean left, boolean right, boolean top, boolean bottom,
      boolean powerStation) {
    this.row = row;
    this.col = col;
    this.left = left;
    this.right = right;
    this.top = top;
    this.bottom = bottom;
    this.powerStation = powerStation;
    this.isLit = false;
    this.powerDistance = 0;
    this.neighbors = new ArrayList<GamePiece>();
    this.connected = new ArrayList<GamePiece>();
    this.outEdges = new ArrayList<Edge>();
    this.stepsTaken = -1;
  }

  // a constructor that only takes in the the row and column numbers
  GamePiece(int width, int height) {
    this(height, width, false, false, false, false, false);
  }

  int cellWidth = 70;
  int cellHeight = cellWidth;

  // ------------------------------------------------------------------------------------

  Color yellow = Color.YELLOW;
  Color gold = new Color(255, 215, 0);
  Color orange = new Color(255, 165, 0);
  Color darkOrange = new Color(255, 140, 0);
  Color red = Color.RED;
  Color maroon = new Color(128, 0, 0);

  ArrayList<Color> colorList = new ArrayList<Color>(
      Arrays.asList(yellow, yellow, yellow, yellow, gold, gold, gold, gold, orange, orange, orange,
          darkOrange, darkOrange, darkOrange, red, red, maroon));

  // draw this gamePiece with all its wires and a powerStation if necessary
  public WorldImage drawGamePiece(GamePiece powerPiece, int powRad) {

    WorldImage bg = new RectangleImage(cellWidth, cellHeight, OutlineMode.SOLID, Color.DARK_GRAY);
    WorldImage frame = new RectangleImage(cellWidth, cellHeight, OutlineMode.OUTLINE, Color.BLACK);
    WorldImage cell = new OverlayImage(frame,
        new OverlayImage(this.drawWires(powerPiece, powRad), bg));

    if (this.powerStation) {
      return new OverlayImage(new StarImage(15, 7, OutlineMode.SOLID, Color.CYAN), cell);
    }
    else {
      return cell;
    }
  }

  // draw the wires of this GamePiece
  public WorldImage drawWires(GamePiece powerPiece, int powRad) {
    WorldImage leftWire = new Utils().drawWire(this.left, "left");
    WorldImage rightWire = new Utils().drawWire(this.right, "right");
    WorldImage topWire = new Utils().drawWire(this.top, "top");
    WorldImage bottomWire = new Utils().drawWire(this.bottom, "bottom");

    WorldImage leftWireLit = new Utils().drawWireLit(this.left, "left", this.powerDistance);
    WorldImage rightWireLit = new Utils().drawWireLit(this.right, "right", this.powerDistance);
    WorldImage topWireLit = new Utils().drawWireLit(this.top, "top", this.powerDistance);
    WorldImage bottomWireLit = new Utils().drawWireLit(this.bottom, "bottom", this.powerDistance);

    WorldImage middle = new RectangleImage(5, 5, OutlineMode.SOLID, Color.LIGHT_GRAY)
        .movePinhole(-1, 0);
    WorldImage middleLit = new RectangleImage(5, 5, OutlineMode.SOLID,
        colorList.get(this.powerDistance)).movePinhole(-1, 0);

    if (this.isLit) {
      return new OverlayImage(middleLit, new OverlayImage(leftWireLit,
          new OverlayImage(rightWireLit, new OverlayImage(topWireLit, bottomWireLit))));
    }
    else {
      return new OverlayImage(middle, new OverlayImage(leftWire,
          new OverlayImage(rightWire, new OverlayImage(topWire, bottomWire))));
    }
  }

  // ------------------------------------------------------------------------------------

  // does this GamePiece have a connection to the given one
  public boolean areConnected(GamePiece other) {
    if (this.row == other.row) {
      return this.areConnectedRow(other);
    }
    else if (this.col == other.col) {
      return this.areConnectedCol(other);
    }
    else {
      return false;
    }
  }

  // does this GamePiece have a connection to the given one,
  // assuming the two exist in the same row
  public boolean areConnectedRow(GamePiece other) {
    if (this.col + 1 == other.col) {
      return this.right && other.left;
    }
    else {
      if (this.col - 1 == other.col) {
        return this.left && other.right;
      }
      else {
        return false;
      }
    }
  }

  // does this GamePiece have a connection to the given one,
  // assuming the two exist in the same column
  public boolean areConnectedCol(GamePiece other) {
    if (this.row - 1 == other.row) {
      return this.top && other.bottom;
    }
    else {
      if (this.row + 1 == other.row) {
        return this.bottom && other.top;
      }
      else {
        return false;
      }
    }
  }

  // ------------------------------------------------------------------------------------

  // EFFECT: rotate the wires on this piece 90 degrees clockwise
  public void rotate() {
    boolean prevLeft = this.left;
    boolean prevRight = this.right;
    boolean prevTop = this.top;
    boolean prevBot = this.bottom;

    this.right = prevTop;
    this.bottom = prevRight;
    this.left = prevBot;
    this.top = prevLeft;
  }

  // EFFECT: rotate the wires on this piece 90 degrees counter-clockwise
  public void unrotate() {
    boolean prevLeft = this.left;
    boolean prevRight = this.right;
    boolean prevTop = this.top;
    boolean prevBot = this.bottom;

    this.top = prevRight;
    this.left = prevTop;
    this.bottom = prevLeft;
    this.right = prevBot;
  }

  // EFFECT: Rotate this piece the given amount of times
  public void rotateAmount(int rotations) {
    if (rotations == 0) {
      // do nothing
    }
    else {
      this.rotate();
      this.rotateAmount(rotations - 1);
    }
  }

  // EFFECT: Rotate this piece counter-clockwise the given amount of times
  public void unrotateAmount(int rotations) {
    if (rotations == 0) {
      // do nothing
    }
    else {
      this.unrotate();
      this.unrotateAmount(rotations - 1);
    }
  }

  // count how many rotations are needed to get back to the original wire layout
  public int countRotationsNeeded(boolean oldL, boolean oldR, boolean oldT, boolean oldB, int acc) {

    if (this.sameWires(oldL, oldR, oldT, oldB)) {
      return acc;
    }
    else {
      this.rotate();
      return this.countRotationsNeeded(oldL, oldR, oldT, oldB, acc + 1);
    }
  }

  // does this piece have the correct wires specified?
  public boolean sameWires(boolean left, boolean right, boolean top, boolean bot) {
    return this.left == left && this.right == right && this.top == top && this.bottom == bot;
  }

  // ------------------------------------------------------------------------------------

  // EFFECT: add all connected pieces in this neighbor list to the connected list
  public void updateConnected() {
    this.connected.clear();

    for (GamePiece gp : this.neighbors) {
      if (this.areConnected(gp)) {
        this.connected.add(gp);
      }
    }
  }

  // EFFECT: Update this piece to contain all necessary edges
  public void updateEdges() {
    for (GamePiece gp : this.connected) {
      this.outEdges.add(new Edge(this, gp));
    }
  }

  // ------------------------------------------------------------------------------------

  // EFFECT: update this piece and all connected pieces to be lit or unlit based
  // on their distances
  public void updateLit(int radius, ArrayList<GamePiece> visited) {
    if (visited.contains(this)) {
      // do nothing
    }
    else if (radius >= 0) {
      this.isLit = true;
      for (GamePiece gp : this.connected) {
        visited.add(this);
        gp.updateLit(radius - 1, visited);
      }
    }
    else {
      this.isLit = false;
    }
  }

  // EFFECT: set the distance of this GamePiece from the power station
  public void setDistances() {

    if (this.powerDistance > 16) {
      this.powerDistance = 16;
    }
  }

  // EFFECT: update the distances of each piece from this piece
  public void updateDistances(int radius, int newRadius, ArrayList<GamePiece> visited) {

    if (visited.contains(this)) {
      // do nothing
    }
    else if (radius >= 0) {
      this.powerDistance = newRadius;
      for (GamePiece gp : this.connected) {
        visited.add(this);
        gp.updateDistances(radius - 1, newRadius + 1, visited);
      }
    }
    else {
      this.powerDistance = newRadius;
    }
  }

  // EFFECT: set the given GamePiece to be the amount of steps away from this piece it is
  public void distance(int steps, GamePiece to, ArrayList<GamePiece> visited) {
    if (visited.contains(this)) {
      // do nothing
    }
    else if (!this.equals(to)) {
      visited.add(this);
      for (GamePiece gp : this.connected) {
        gp.distance(steps + 1, to, visited);
      }
    }
    else if (this.equals(to)) {
      this.stepsTaken = steps;
    }
  }

  // find the distance between this piece and the piece given
  public int findDistance(GamePiece to) {
    this.distance(0, to, new ArrayList<GamePiece>());

    return to.stepsTaken;
  }

  // ------------------------------------------------------------------------------------

  // count how many pieces this GamePiece is connected to through its edges
  public int countConnected() {
    return this.connectedPieces(new ArrayList<GamePiece>());
  }

  // count how many pieces this can reach going through its edges
  public int connectedPieces(ArrayList<GamePiece> allPieces) {
    for (GamePiece gp : this.connected) {
      if (allPieces.contains(gp)) {
        // do nothing
      }
      else {
        allPieces.add(gp);
        gp.connectedPieces(allPieces);
      }
    }
    return allPieces.size();
  }

  // count the amount of pieces this is connected to after the addition of the
  // given edge
  public int countAfterConnections(Edge e) {
    this.connected.add(e.toNode);
    return this.countConnected();
  }

  // create a list of every possible edge in this board with random weights
  public ArrayList<Edge> allPossibleEdges(Random rand) {
    ArrayList<Edge> edgeList = new ArrayList<Edge>();

    for (GamePiece gp : this.neighbors) {
      edgeList.add(new Edge(this, gp, rand.nextInt(100)));
    }
    return edgeList;
  }

  // EFFECT: Update the outedge list, the wires, and the connections of this piece
  // based on the given edge
  public void addEdgeWireConnection(Edge e) {
    GamePiece toNode = e.toNode;

    this.outEdges.add(e);
    toNode.outEdges.add(e);
    this.addWire(e);
    this.connected.add(e.toNode);
    toNode.connected.add(this);
  }

  // EFFECT: add the wire of this piece and the other piece based on the edge
  // given
  public void addWire(Edge e) {
    GamePiece toPiece = e.toNode;
    String direction = this.whichDirection(e.toNode);

    if (direction.equals("right")) {
      this.right = true;
      toPiece.left = true;
    }
    else if (direction.equals("left")) {
      this.left = true;
      toPiece.right = true;
    }
    else if (direction.equals("top")) {
      this.top = true;
      toPiece.bottom = true;
    }
    else {
      this.bottom = true;
      toPiece.top = true;
    }
  }

  // determine the direction of the second piece in relation to this one
  public String whichDirection(GamePiece p2) {
    if (this.row == p2.row) {
      if (this.col < p2.col) {
        return "right";
      }
      else {
        return "left";
      }
    }
    else {
      if (this.row < p2.row) {
        return "bottom";
      }
      else {
        return "top";
      }
    }
  }

  // ------------------------------------------------------------------------------------

}